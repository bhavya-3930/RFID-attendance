# RFID-Attendance-system
This is the new version of the RFID attendance system that uses NodeMCU or ESP32 with RFID module to send the Card IDs to the website to store the data into the website database


If you find my work helpful, it would be kind to have a cup of coffee from you,


<a href="https://www.buymeacoffee.com/1rp8CJx" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-green.png" alt="Buy Me A Coffee" height="60" width="217" ></a>
